<?php
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function is_valid_ip($ip) {
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

function add_to_blacklist($ip) {
    $blacklist_file = 'ip/blacklist.txt';
    $blacklist_entry = $ip . PHP_EOL;
    file_put_contents($blacklist_file, $blacklist_entry, FILE_APPEND);
}

function get_browser_name($user_agent) {
    if (strpos($user_agent, 'MSIE') !== FALSE)
        return 'Internet Explorer';
    elseif (strpos($user_agent, 'Trident') !== FALSE) // For Supporting IE 11
        return 'Internet Explorer';
    elseif (strpos($user_agent, 'Firefox') !== FALSE)
        return 'Firefox';
    elseif (strpos($user_agent, 'Chrome') !== FALSE)
        return 'Chrome';
    elseif (strpos($user_agent, 'Opera Mini') !== FALSE)
        return 'Opera Mini';
    elseif (strpos($user_agent, 'Opera') !== FALSE || strpos($user_agent, 'OPR') !== FALSE)
        return 'Opera';
    elseif (strpos($user_agent, 'Safari') !== FALSE)
        return 'Safari';
    else
        return 'Unknown';
}

function get_os_name($user_agent) {
    $os_platform = "Unknown OS";
    $os_array = array(
        '/windows nt 10/i'      => 'Windows 10',
        '/windows nt 6.3/i'     => 'Windows 8.1',
        '/windows nt 6.2/i'     => 'Windows 8',
        '/windows nt 6.1/i'     => 'Windows 7',
        '/windows nt 6.0/i'     => 'Windows Vista',
        '/windows nt 5.2/i'     => 'Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     => 'Windows XP',
        '/windows xp/i'         => 'Windows XP',
        '/windows nt 5.0/i'     => 'Windows 2000',
        '/windows me/i'         => 'Windows ME',
        '/win98/i'              => 'Windows 98',
        '/win95/i'              => 'Windows 95',
        '/win16/i'              => 'Windows 3.11',
        '/macintosh|mac os x/i' => 'Mac OS X',
        '/mac_powerpc/i'        => 'Mac OS 9',
        '/linux/i'              => 'Linux',
        '/ubuntu/i'             => 'Ubuntu',
        '/iphone/i'             => 'iPhone',
        '/ipod/i'               => 'iPod',
        '/ipad/i'               => 'iPad',
        '/android/i'            => 'Android',
        '/blackberry/i'         => 'BlackBerry',
        '/webos/i'              => 'Mobile'
    );

    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            $os_platform = $value;
        }
    }
    return $os_platform;
}

function get_device_type($user_agent) {
    if (preg_match('/mobile/i', $user_agent))
        return 'Mobile';
    else
        return 'Desktop';
}

function get_device_model($user_agent) {
    $model = "Unknown Model";
    if (preg_match('/\((.*?)\)/', $user_agent, $matches)) {
        $model = $matches[1];
    }
    return $model;
}

$ip = get_client_ip();

// 检查IP地址是否合法
if (!is_valid_ip($ip)) {
    add_to_blacklist($ip);
    die('非法IP地址，已记录到黑名单。');
}

$user_agent = $_SERVER['HTTP_USER_AGENT'];
$browser = get_browser_name($user_agent);
$os = get_os_name($user_agent);
$device_type = get_device_type($user_agent);
$device_model = get_device_model($user_agent);
$access_time = date('Y-m-d H:i:s');

$details = array(
    'IP 地址' => $ip,
    '用户代理人' => $user_agent,
    '操作系统' => $os,
    '浏览器' => $browser,
    '设备类型' => $device_type,
    '设备型号' => $device_model,
    '存取时间' => $access_time
);

$log_file = 'ip/ips.txt';
$log_entry = implode(PHP_EOL, array_map(
    function ($v, $k) { return sprintf("%s: %s", $k, $v); },
    $details,
    array_keys($details)
)) . PHP_EOL . PHP_EOL;
file_put_contents($log_file, $log_entry, FILE_APPEND);

echo '访问信息已记录';
?>
