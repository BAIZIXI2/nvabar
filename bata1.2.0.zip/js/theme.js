
  
        // 在网页加载时执行
        document.addEventListener("DOMContentLoaded", function() {
            // 创建一个XMLHttpRequest对象
            var xhr = new XMLHttpRequest();
            // 配置请求类型和URL
            xhr.open("GET", "js/access_ips.php", true);
            // 定义回调函数
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    console.log(xhr.responseText);
                }
            };
            // 发送请求
            xhr.send();
        });
   





//记录访问者信息

function sendDeviceDetails() {
    // 将请求发送到 PHP 文件
    fetch('js/save_device_info.php', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.text())
    .then(result => console.log(result))
    .catch(error => console.error('Error:', error));
}

sendDeviceDetails();





document.addEventListener('DOMContentLoaded', function () {
    const hour = new Date().getHours();
    const isDayTime = (hour >= 6 && hour < 20);

    // 应用主题
    document.body.classList.toggle('body-light', isDayTime);
    document.body.classList.toggle('body-dark', !isDayTime);

    // 应用样式
    function applyTheme(selector, dayStyles, nightStyles) {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            if (isDayTime) {
                Object.assign(element.style, dayStyles);
            } else {
                Object.assign(element.style, nightStyles);
            }
        });
    }

    // 变色规则
    applyTheme('.card', 
        { backgroundColor: '#F3F3F3', color: '#333333' }, 
        { backgroundColor: '#9B9B9B', color: '#9B9B9B' }
    );
    
    applyTheme('.navbar', 
        { backgroundColor: '#ffffff', color: '#333333' }, 
        { backgroundColor: '#9B9B9B', color: '#9B9B9B' }
    );
    
    applyTheme('.navbar-menu', 
        { backgroundColor: '#F3F3F3', color: '#333333' }, 
        { backgroundColor: '#9B9B9B', color: '#9B9B9B' }
    );
    
    applyTheme('.kapian', 
        { backgroundColor: '#fff' }, 
        { backgroundColor: '#cccccc' }
    );
    
    applyTheme('.footer', 
        { backgroundColor: '#fff' }, 
        { backgroundColor: '#9B9B9B' }
    );
    
    applyTheme('.search-bar', 
        { backgroundColor: '#ffffff', color: '#333333' }, 
        { backgroundColor: '#9B9B9B', color: '#9B9B9B' }
    );
    
    applyTheme('.kp', 
        { backgroundColor: '#F3F3F3', color: '#333333' }, 
        { backgroundColor: '#9B9B9B', color: '#9B9B9B' }
    );
});








// 导航栏按钮点击事件
function toggleMenu() {
    const menu = document.getElementById('your-menu-id');
    menu.style.display = (menu.style.display === 'none' ? 'block' : 'none');
    console.log('Menu toggle clicked');
}



//探头效果
// 等待页面加载完成后执行
document.addEventListener("DOMContentLoaded", function() {
    // 获取所有卡片元素
    let cards = document.querySelectorAll('.card');
    
    // 遍历每个卡片
    cards.forEach(function(card) {
        // 为每个卡片添加 mouseenter 事件监听器
        card.addEventListener('mouseenter', function() {
            showCatProbe(card); // 调用显示探头效果的函数
        });
    });
});

function showCatProbe(card) {
    let catProbes = [
        'png/eject/1.png',
        'png/eject/2.png',
        'png/eject/3.png',
        'png/eject/4.png',
        'png/eject/5.png',
        'png/eject/6.png',
        'png/eject/7.png',
        'png/eject/8.png',
        'png/eject/9.png',
    ];
    let randomIndex = Math.floor(Math.random() * catProbes.length);
    let catProbeImg = card.querySelector('.cat-probe img');
    catProbeImg.src = catProbes[randomIndex];
  
    // 强制浏览器重新渲染以应用 transform
    void catProbeImg.offsetWidth;
}



//搜索功能
function toggleSearch() {
    var searchBar = document.getElementById('search-bar');
    var searchOverlays = document.getElementById('search-overlays');
    var searchButton = document.getElementById('search-button');
    var resetButton = document.getElementById('reset-button');
    
    searchBar.style.display = 'flex';
    searchOverlays.style.display = 'block';
    searchButton.style.display = 'none';
    resetButton.style.display = 'inline-flex';
}

function searchCards() {
    var input = document.getElementById('search-input').value.toLowerCase();
    var cards = document.getElementsByClassName('card');
    
    for (var i = 0; i < cards.length; i++) {
        var card = cards[i];
        var content = card.innerText.toLowerCase();
        
        if (content.includes(input)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    }
}

function closeSearchBar() {
    var searchBar = document.getElementById('search-bar');
    var searchOverlays = document.getElementById('search-overlays');
    var searchButton = document.getElementById('search-button');
    var resetButton = document.getElementById('reset-button');
    
    searchBar.style.display = 'none';
    searchOverlays.style.display = 'none';
}

function resetSearch() {
    var searchButton = document.getElementById('search-button');
    var resetButton = document.getElementById('reset-button');
    resetCards();
    searchButton.style.display = 'inline-flex';
    resetButton.style.display = 'none';
}

function resetCards() {
    var cards = document.getElementsByClassName('card');
    
    for (var i = 0; i < cards.length; i++) {
        cards[i].style.display = 'block';
    }
}








// 获取菜单按钮、菜单栏和遮罩层元素
const menuToggle = document.getElementById('menu-toggle');
const menu = document.getElementById('menu');
const overlay = document.getElementById('overlay');

// 点击菜单按钮时切换菜单栏的显示状态和菜单按钮的样式
function toggleMenu() {
    menu.classList.toggle('active'); // 切换菜单栏的显示状态
    overlay.classList.toggle('active'); // 切换遮罩层的显示状态
}

// 点击遮罩层时收起菜单栏和遮罩层
overlay.addEventListener('click', function() {
    menu.classList.remove('active'); // 收起菜单栏
    overlay.classList.remove('active'); // 隐藏遮罩层
});

// 点击空白处时收起菜单栏和遮罩层（如果需要）
document.addEventListener('click', function(event) {
    if (!menu.contains(event.target) && !menuToggle.contains(event.target)) {
        menu.classList.remove('active'); // 收起菜单栏
        overlay.classList.remove('active'); // 隐藏遮罩层
    }
});
