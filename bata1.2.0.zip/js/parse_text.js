document.addEventListener('DOMContentLoaded', () => {
    fetch('js/txt/隐私政策.txt')
        .then(response => response.text())
        .then(text => {
            // 处理多种嵌套格式符号
            text = parseNestedFormatting(text);
            text = text.replace(/\n/g, '<br>'); // 处理换行

            document.getElementById('parsed-content').innerHTML = text;
        })
        .catch(error => console.error('Error fetching the text file:', error));
});

function parseNestedFormatting(text) {
    // 处理加粗
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // 处理斜体
    text = text.replace(/##(.*?)##/g, '<i>$1</i>');
    // 处理加粗并居中
    text = text.replace(/\/\/(.*?)\/\//g, '<div style="text-align: center; font-weight: bold;">$1</div>');
    // 处理整行居中
    text = text.replace(/^\^\^(.*?)$/gm, '<div style="text-align: center;">$1</div>');
    // 处理超链接
    text = text.replace(/%(.*?)%(.*?)%/g, '<a href="$1" style="color: blue; text-decoration: none;">$2</a>');

    // 递归处理剩余的嵌套格式
    if (text.match(/\*\*.*?\*\*|##.*?##|\/\/.*?\/\/|\^\^.*?$|%(.*?)%(.*?)%/)) {
        text = parseNestedFormatting(text);
    }

    return text;
}
